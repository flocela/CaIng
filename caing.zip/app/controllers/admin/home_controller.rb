class Admin::HomeController < ApplicationController
  def index
  end
end
